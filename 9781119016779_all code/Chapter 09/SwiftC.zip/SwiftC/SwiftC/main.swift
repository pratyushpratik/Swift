import Foundation

let x: Int32 = 10;
let xSquared = square(x)
let xCubed = cube(x)
println("x is \(x)")
println("x^2 is \(xSquared)")
println("x^3 is \(xCubed)")
