#ifndef __SwiftC__exponents__
#define __SwiftC__exponents__

#include <stdio.h>

extern int square(int x);
extern int cube(int x);

#endif
