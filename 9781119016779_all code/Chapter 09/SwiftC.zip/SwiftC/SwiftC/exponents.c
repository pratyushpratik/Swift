#include "exponents.h"
#include "math.h"

int square(int x)
{
    return (int) pow(x, 2);
}

int cube(int x)
{
    return (int) pow(x, 3);
}
