import UIKit

class ViewController: UITableViewController {

    let firebase = Firebase(hostname: "your-hostname.firebaseio.com")
    var albums: [Album] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.reloadData()
    }

    private func reloadData() {
        firebase.fetchAlbums { (albums, error) in
            if let error = error {
                self.showAlert(error)
            } else {
                if let albums = albums {
                    self.albums = albums
                    self.albums.sort { $0 < $1 }
                    self.tableView.reloadData()
                }
            }
        }
    }

    private func showAlert(error: NSError) {
        let alert = UIAlertView(
            title: "Oops!",
            message: "Could not fetch albums data.",
            delegate: nil,
            cancelButtonTitle: "OK")
        alert.show()
    }

    // MARK: Table view data source

    override func tableView(tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return albums.count
    }

    override func tableView(tableView: UITableView,
                            cellForRowAtIndexPath indexPath: NSIndexPath)
        -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier(
            "AlbumCell") as UITableViewCell?
        if cell == nil {
            cell = UITableViewCell(
                style: UITableViewCellStyle.Default,
                reuseIdentifier: "AlbumCell")
        }
        cell!.textLabel?.text = albums[indexPath.row].description
        return cell!
    }

    override func tableView(tableView: UITableView,
                            canEditRowAtIndexPath indexPath: NSIndexPath)
        -> Bool {
        return true;
    }

    override func tableView(
        tableView: UITableView,
        commitEditingStyle editingStyle: UITableViewCellEditingStyle,
        forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            let album = albums[indexPath.row]
            firebase.deleteAlbum(album, completionHandler: { (error) in
                if let error = error {
                    self.showAlert(error)
                } else {
                    self.albums.removeAtIndex(indexPath.row)
                    self.tableView.deleteRowsAtIndexPaths([indexPath],
                        withRowAnimation: UITableViewRowAnimation.Automatic)
                }
            })
        }
    }

    // MARK: Add album

    @IBAction func cancel(segue: UIStoryboardSegue) {
    }

    @IBAction func add(segue: UIStoryboardSegue) {
        let detailController = segue.sourceViewController as AddAlbumViewController
        firebase.saveAlbum(detailController.album) { (albumID, error) in
            if let error = error {
                self.showAlert(error)
            } else {
                self.reloadData()
            }
        }

        dismissViewControllerAnimated(true, completion: nil)
    }
}
