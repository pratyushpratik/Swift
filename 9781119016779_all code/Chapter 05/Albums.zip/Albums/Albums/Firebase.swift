import Foundation


typealias FirebaseSaveCompletion = (String?, NSError?) -> Void
typealias FirebaseFetchCompletion = ([Album]?, NSError?) -> Void
typealias FirebaseDeleteCompletion = (NSError?) -> Void


class Firebase {
    let hostname: String
    var albumsURL: NSURL {
        return NSURL(scheme: "https", host: hostname, path: "/albums.json")!
    }

    init(hostname: String) {
        self.hostname = hostname
    }

    func fetchAlbums(completionHandler: FirebaseFetchCompletion) {
        var request = NSURLRequest(URL: albumsURL)
        NSURLConnection.sendAsynchronousRequest(
            request, queue: NSOperationQueue.currentQueue()) {
                (response, data, error) in
            if let error = error {
                completionHandler(nil, error)
                return
            }

            var err: NSError?
            let json: AnyObject? = NSJSONSerialization.JSONObjectWithData(
                data,
                options: NSJSONReadingOptions(0),
                error: &err)
            if let err = err {
                completionHandler(nil, error)
                return
            }

            if let json: AnyObject = json {
                if let json = json as? [String: AnyObject] {
                    var albums: [Album] = []
                    for (key, item) in json {
                        if let item = item as? [String: String] {
                            var album = Album(band: item["band"]!,
                                              title: item["title"]!)
                            album.id = key
                            albums.append(album)
                        }
                    }
                    completionHandler(albums, nil)
                    return
                }
                completionHandler(nil,
                    NSError(domain: "albums", code: 100, userInfo: nil))
                return
            } else {
                completionHandler(nil,
                    NSError(domain: "albums", code: 101, userInfo: nil))
                return
            }
        }
    }

    func saveAlbum(album: Album, completionHandler: FirebaseSaveCompletion) {
        var err: NSError?
        let data = NSJSONSerialization.dataWithJSONObject(
            album.toJSON(),
            options: NSJSONWritingOptions(0),
            error: &err)
        if let err = err {
            completionHandler(nil, err)
            return
        }

        var request = NSMutableURLRequest(URL: albumsURL)
        request.HTTPMethod = "POST"
        request.HTTPBody = data

        NSURLConnection.sendAsynchronousRequest(
            request, queue: NSOperationQueue.currentQueue()) {
                (response, data, error) in
            if let error = error {
                completionHandler(nil, error)
                return
            }

            err = nil
            let obj: AnyObject? = NSJSONSerialization.JSONObjectWithData(
                data,
                options: NSJSONReadingOptions(0),
                error: &err)
            if let err = err {
                completionHandler(nil, err)
                return
            }
            if let obj: AnyObject = obj {
                if let albumDict = obj as? [String: String] {
                    let albumID = albumDict["name"]!
                    completionHandler(albumID, nil)
                }
            } else {
                completionHandler(
                    nil, NSError(domain: "albums", code: 102, userInfo: nil))
            }
        }
    }

    func deleteAlbum(album: Album, completionHandler: FirebaseDeleteCompletion) {
        if album.id == nil {
            completionHandler(NSError(domain: "albums", code: 103, userInfo: nil))
            return
        }

        let deleteURL = NSURL(scheme: "https",
                              host: hostname,
                              path: "/albums/\(album.id!).json")!
        var request = NSMutableURLRequest(URL: deleteURL)
        request.HTTPMethod = "DELETE"

        NSURLConnection.sendAsynchronousRequest(
            request, queue: NSOperationQueue.currentQueue()) {
                (response, data, error) in
            if let error = error {
                completionHandler(error)
            } else {
                completionHandler(nil)
            }
        }
    }
}
