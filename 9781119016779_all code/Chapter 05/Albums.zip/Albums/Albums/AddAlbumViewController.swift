import UIKit

class AddAlbumViewController: UITableViewController {
    @IBOutlet weak var albumTitleField: UITextField!
    @IBOutlet weak var bandField: UITextField!
    var album: Album!

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "SaveAlbum" {
            album = Album(band: bandField.text, title: albumTitleField.text)
        }
    }
}
