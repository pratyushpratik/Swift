import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func sliderChanged(sender: UISlider) {
        let val = sender.value
        let circleView = view as CircleView
        circleView.circleRadius = CGFloat(val)
        view.setNeedsDisplay()
    }
}
