import UIKit


class CircleView: UIView {
    var strokeColor: UIColor
    var strokeWidth: CGFloat
    var circleRadius: CGFloat

    override init(frame: CGRect) {
        strokeColor = UIColor.redColor()
        strokeWidth = 5.0
        circleRadius = 75.0
        super.init(frame: frame)
    }

    required init(coder aDecoder: NSCoder) {
        strokeColor = UIColor.redColor()
        strokeWidth = 5.0
        circleRadius = 75.0
        super.init(coder: aDecoder)
    }

    override func drawRect(rect: CGRect) {
        super.drawRect(rect)

        let middleX = CGRectGetMidX(rect)
        let middleY = CGRectGetMidY(rect)

        var ctx = UIGraphicsGetCurrentContext()
        CGContextSetLineWidth(ctx, strokeWidth)
        strokeColor.set()
        CGContextAddArc(ctx, middleX, middleX, circleRadius, 0.0, CGFloat(M_PI * 2.0), 1)
        CGContextStrokePath(ctx)
    }
}
