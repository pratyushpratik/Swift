#import "Rectangle.h"


@implementation Rectangle

@synthesize identifier, length, width;

+ (instancetype)rectangleWithIdentifier:(NSString *)anIdentifier length:(NSNumber *)aLength width:(NSNumber *)aWidth
{
    return [[self alloc] initWithIdentifier:anIdentifier length:aLength width:aWidth];
}

- (instancetype)initWithIdentifier:(NSString *)anIdentifier length:(NSNumber *)aLength width:(NSNumber *)aWidth
{
    if ((self = [super init])) {
        identifier = [anIdentifier copy];
        length = aLength;
        width = aWidth;
    }
    return self;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@ <identifier=%@, length=%@, width=%@>", self.class, self.identifier, self.length, self.width];
}

@end
