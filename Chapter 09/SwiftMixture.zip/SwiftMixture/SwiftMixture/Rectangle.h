#import <Foundation/Foundation.h>


@interface Rectangle : NSObject

@property (copy, nonatomic) NSString *identifier;
@property (strong, nonatomic) NSNumber *length;
@property (strong, nonatomic) NSNumber *width;

+ (instancetype)rectangleWithIdentifier:(NSString *)anIdentifier length:(NSNumber *)aLength width:(NSNumber *)aWidth;
- (instancetype)initWithIdentifier:(NSString *)anIdentifier length:(NSNumber *)aLength width:(NSNumber *)aWidth;

@end
