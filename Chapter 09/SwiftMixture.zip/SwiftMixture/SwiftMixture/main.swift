import Foundation

let rectangle = Rectangle(identifier: "My Rectangle", length: 40, width: 20)
println(rectangle)
